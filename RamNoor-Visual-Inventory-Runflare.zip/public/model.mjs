export const types={tube:{label:'لوله',unit:'متر'},sheet:{label:'ورق',unit:'مترمربع'},profile:{label:'پروفیل',unit:'متر'}};
export const kinds={receipt:'ورود موجودی',reserve:'رزرو سفارش',release:'آزادسازی رزرو',issue:'خروج و مصرف',return:'برگشت به انبار',transfer:'انتقال مکان',correct:'اصلاح ابعاد'};
export const digits=s=>String(s??'').replace(/[۰-۹]/g,c=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(c)).replace(/[٠-٩]/g,c=>'٠١٢٣٤٥٦٧٨٩'.indexOf(c)).replace(/٫/g,'.');
export const norm=s=>digits(s).trim().toLowerCase().replace(/ي/g,'ی').replace(/ك/g,'ک').replace(/\s+/g,' ');
export const fa=n=>new Intl.NumberFormat('fa-IR',{maximumFractionDigits:3}).format(n);
export const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const jf=new Intl.DateTimeFormat('en-US-u-ca-persian',{year:'numeric',month:'numeric',day:'numeric',timeZone:'UTC'});
const dateParts=d=>Object.fromEntries(jf.formatToParts(d).filter(p=>['year','month','day'].includes(p.type)).map(p=>[p.type,Number(p.value)]));
export function jalaliDay(s){
  const m=digits(s).trim().match(/^(1[34]\d{2})[\/-](\d{1,2})[\/-](\d{1,2})$/);if(!m)return null;
  const [y,mo,da]=m.slice(1).map(Number);if(mo<1||mo>12||da<1||da>31)return null;
  let start=null;for(let i=0;i<35;i++){const t=Date.UTC(y+621,2,1)+i*86400000,p=dateParts(new Date(t));if(p.year===y&&p.month===1&&p.day===1){start=t;break;}}
  if(start===null)return null;const offset=mo<=7?(mo-1)*31:186+(mo-7)*30,ts=start+(offset+da-1)*86400000,p=dateParts(new Date(ts));return p.year===y&&p.month===mo&&p.day===da?ts/86400000:null;
}
export function today(){const f=new Intl.DateTimeFormat('en-US-u-ca-persian',{year:'numeric',month:'2-digit',day:'2-digit',timeZone:'Asia/Tehran'}),p=Object.fromEntries(f.formatToParts(new Date()).map(x=>[x.type,x.value]));return p.year+'/'+p.month+'/'+p.day;}
export function dims(g){return g.type==='tube'?'قطر خارجی '+fa(g.diameter)+' · ضخامت '+fa(g.thickness):g.type==='profile'?'مقطع '+fa(g.width)+' × '+fa(g.height)+' · ضخامت '+fa(g.thickness):'ضخامت '+fa(g.thickness);}
export function size(g,p){return g.type==='sheet'?fa(p.width)+' × '+fa(p.length)+' میلی‌متر':fa(p.length)+' متر';}
export function measure(g,p){return g.type==='sheet'?p.width*p.length/1e6:p.length;}
