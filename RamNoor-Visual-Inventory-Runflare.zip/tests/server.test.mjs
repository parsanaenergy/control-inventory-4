import test from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import {once} from 'node:events';
import {DatabaseSync} from 'node:sqlite';
const cwd=new URL('../',import.meta.url);
test('HTTP: authenticated app, atomic commands, export and live database backup',async t=>{
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'rn-http-'));
 const child=spawn(process.execPath,['server.mjs'],{cwd,env:{...process.env,RAMNOOR_HOST:'127.0.0.1',PORT:'0',RAMNOOR_DB_PATH:path.join(dir,'inventory.sqlite'),RAMNOOR_AUTH_USER:'tester',RAMNOOR_AUTH_PASSWORD:'test-only-password',PUBLIC_ORIGIN:'https://inventory.example.test'},stdio:['ignore','pipe','pipe']});
 t.after(async()=>{if(child.exitCode===null){const ended=once(child,'exit');child.kill();await ended;}await fs.rm(dir,{recursive:true,force:true});});
 let logs='';child.stderr.on('data',b=>logs+=b);const base=await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(new Error('Startup timeout '+logs)),10000);child.once('exit',()=>{clearTimeout(timer);reject(new Error(logs));});child.stdout.on('data',b=>{const m=b.toString().match(/http:\/\/[^\s]+/);if(m){clearTimeout(timer);resolve(m[0].replace(/\/$/,''));}});});
 const auth='Basic '+Buffer.from('tester:test-only-password').toString('base64');const headers={authorization:auth};
 assert.equal((await fetch(base+'/healthz')).status,200);assert.equal((await fetch(base+'/')).status,401);assert.equal((await fetch(base+'/api/state')).status,401);
 const home=await fetch(base+'/',{headers});assert.equal(home.status,200);assert.match(await home.text(),/lang="fa"/);assert.match(home.headers.get('content-security-policy'),/script-src 'self'/);
 assert.equal((await fetch(base+'/api/state',{headers}).then(r=>r.json())).revision,0);
 const command={requestId:randomUUID(),revision:0,kind:'receipt',payload:{type:'tube',material:'=TEST()',diameter:60.3,thickness:2,length:6,count:2,remnant:false,location:'A',operator:'tester',document:'R-1',date:'1405/07/16',note:'',order:''}};
 const post=(body,origin='https://inventory.example.test')=>fetch(base+'/api/commands',{method:'POST',headers:{...headers,'content-type':'application/json',origin},body:JSON.stringify(body)});
 assert.equal((await post(command,'https://other.example')).status,403);const first=await post(command);assert.equal(first.status,200);const result=await first.json();assert.equal(result.pieceIds.length,2);
 const retry=await post(command).then(r=>r.json());assert.equal(retry.duplicate,true);assert.equal((await post({...command,requestId:randomUUID()})).status,409);
 assert.equal((await fetch(base+'/api/request?id='+command.requestId,{headers}).then(r=>r.json())).found,true);
 const state=await fetch(base+'/api/state',{headers}).then(r=>r.json());assert.equal(state.summary.tube.total,12);const rack=await fetch(base+'/api/rack?id='+encodeURIComponent(state.racks[0].rackId),{headers}).then(r=>r.json());assert.equal(rack.pieces.length,2);
 const csv=await fetch(base+'/api/export.csv',{headers}).then(r=>r.text());assert.ok(csv.includes("'=TEST()"));assert.ok(csv.includes('T-000001'));
 const backup=await fetch(base+'/api/backup',{headers});assert.equal(backup.status,200);const backupFile=path.join(dir,'download.sqlite');await fs.writeFile(backupFile,Buffer.from(await backup.arrayBuffer()));const db=new DatabaseSync(backupFile);try{assert.equal(db.prepare('SELECT COUNT(*) n FROM pieces').get().n,2);}finally{db.close();}
 assert.equal((await fetch(base+'/api/not-a-route',{headers})).status,404);assert.equal((await fetch(base+'/server.mjs',{headers})).status,404);
});
test('network binding requires login credentials',async()=>{
 const child=spawn(process.execPath,['server.mjs'],{cwd,env:{...process.env,RAMNOOR_HOST:'0.0.0.0',RAMNOOR_AUTH_USER:'',RAMNOOR_AUTH_PASSWORD:''},stdio:['ignore','ignore','pipe']});let error='';child.stderr.on('data',b=>error+=b);const [code]=await once(child,'exit');assert.notEqual(code,0);assert.match(error,/Configure authentication/);
});
